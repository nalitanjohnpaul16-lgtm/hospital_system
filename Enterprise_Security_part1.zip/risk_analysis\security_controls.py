def show_security_controls():
    print("\n--- SECURITY CONTROLS PLAN ---")
    print("Physical Controls: CCTV, biometric access doors, locked server room, visitor logbook")
    print("Technical Controls: Firewalls, antivirus, VPN, encryption, MFA, password hashing, IDS/IPS")
    print("Administrative Controls: Data privacy policy, IT security training, internal audits, backup documentation")
